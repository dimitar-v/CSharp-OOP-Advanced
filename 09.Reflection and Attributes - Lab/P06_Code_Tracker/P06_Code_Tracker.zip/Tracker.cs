﻿using System;
using System.Reflection;


public class Tracker
{
    public void PrintMethodsByAuthor()
    {
        var type = typeof(StartUp);

        var methodes = type.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.Static);


        foreach (var method in methodes)
        {
            var attr = method.GetCustomAttribute<SoftUniAttribute>();

            if (attr != null)
            {
                Console.WriteLine($"{method.Name} is writen by {attr.Name}");
            }

        }

        //methodes.ToList()
        //    .ForEach(m => m.GetCustomAttributes(false)
        //            .ToList()   
        //            .ForEach(a => Console.WriteLine($"{m.Name} is writen by {a.Name}")));

    }
}

