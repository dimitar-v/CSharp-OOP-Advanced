﻿namespace IntDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
