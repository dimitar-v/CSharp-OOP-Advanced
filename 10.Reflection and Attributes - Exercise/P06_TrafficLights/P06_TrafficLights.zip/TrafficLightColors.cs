﻿namespace P06_TrafficLights
{
    public enum TrafficLightColors
    {
        Red = 0,
        Green = 1,
        Yellow = 2
    }
}
